package org.restlet.example.security.authentication;

import org.restlet.data.Protocol;
import org.restlet.data.Status;
import org.restlet.resource.Get;
import org.restlet.resource.Patch;
import org.restlet.resource.Post;
import org.restlet.resource.ResourceException;
import org.restlet.resource.ServerResource;

public class ResourceFineGrained extends ServerResource {

	@Get
	public String represent() throws ResourceException {
		if (!getRequest().getProtocol().equals(Protocol.HTTPS)) {
			throw new ResourceException(new Status(426, "Upgrade required", "You should switch to HTTPS", "http://tools.ietf.org/html/rfc2817"));
		}
        return this.getClass().getSimpleName() + " found !";
	}
	
	@Post
	public String postMe() {
		if (!isInRole(ApiWithRoleAuthorization.ROLE_OWNER)) {
			throw new ResourceException(Status.CLIENT_ERROR_FORBIDDEN);
		}
		return this.getClass().getSimpleName() + " posted !";
	}
	
	@Patch
	public String patchMe() {
		if (!getClientInfo().isAuthenticated()) {
			throw new ResourceException(Status.CLIENT_ERROR_METHOD_NOT_ALLOWED);
		}
		return this.getClass().getSimpleName() + " patched !";
	}
}
