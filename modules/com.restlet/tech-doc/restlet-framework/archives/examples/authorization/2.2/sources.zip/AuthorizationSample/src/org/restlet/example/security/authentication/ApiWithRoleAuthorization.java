package org.restlet.example.security.authentication;

import org.restlet.Application;
import org.restlet.Component;
import org.restlet.Restlet;
import org.restlet.data.ChallengeScheme;
import org.restlet.data.Protocol;
import org.restlet.routing.Router;
import org.restlet.security.ChallengeAuthenticator;
import org.restlet.security.MemoryRealm;
import org.restlet.security.Role;
import org.restlet.security.RoleAuthorizer;
import org.restlet.security.User;

public class ApiWithRoleAuthorization extends Application {

    //Define role names
    public static final String ROLE_USER = "user";
    public static final String ROLE_OWNER = "owner";

    @Override
    public Restlet createInboundRoot() {
        //Create the authenticator, the authorizer and the router that will be protected
        ChallengeAuthenticator authenticator = createAuthenticator();
        RoleAuthorizer authorizer = createRoleAuthorizer();
        Router router = createRouter();

    	Router baseRouter = new Router(getContext());
        
        //Protect the resource by enforcing authentication then authorization
        authorizer.setNext(Resource0.class);
        authenticator.setNext(baseRouter);
    	
    	//Protect only the private resources with authorizer
    	//You could use several different authorizers to authorize different roles
    	baseRouter.attach("/resourceTypePrivate", authorizer);
    	baseRouter.attach("/resourceTypePublic", router);
        return authenticator;
    }
    
    private ChallengeAuthenticator createAuthenticator() {
        ChallengeAuthenticator guard = new ChallengeAuthenticator(
                getContext(), ChallengeScheme.HTTP_BASIC, "realm");

        //Create in-memory users with roles
        MemoryRealm realm = new MemoryRealm();
        User user = new User("user", "user");
        realm.getUsers().add(user);
        realm.map(user, Role.get(this, ROLE_USER));
        User owner = new User("owner", "owner");
        realm.getUsers().add(owner);
        realm.map(owner, Role.get(this, ROLE_OWNER));
        
        //Attach verifier to check authentication and enroler to determine roles
        guard.setVerifier(realm.getVerifier());
        guard.setEnroler(realm.getEnroler());
        return guard;
    }
    
    private RoleAuthorizer createRoleAuthorizer() {
    	//Authorize owners and forbid users on roleAuth's children
    	RoleAuthorizer roleAuth = new RoleAuthorizer();
    	roleAuth.getAuthorizedRoles().add(Role.get(this, ROLE_OWNER));
    	roleAuth.getForbiddenRoles().add(Role.get(this, ROLE_USER));
    	return roleAuth;
    }

    private Router createRouter() {
        //Attach Server Resources to given URL
        Router router = new Router(getContext());
        router.attach("/resource1/", Resource1.class);
        router.attach("/resource2/", Resource2.class);
        return router;
    }
    
    public static void main(String[] args) throws Exception {
        //Attach application to http://localhost:9000/v1
        Component c = new Component();
        c.getServers().add(Protocol.HTTP, 9000);
        c.getDefaultHost().attach("/v1", new ApiWithRoleAuthorization());
        c.start();
    }
}