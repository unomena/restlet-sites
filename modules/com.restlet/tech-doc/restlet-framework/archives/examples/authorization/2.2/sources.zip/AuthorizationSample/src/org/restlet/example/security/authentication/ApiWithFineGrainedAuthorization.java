package org.restlet.example.security.authentication;

import org.restlet.Application;
import org.restlet.Component;
import org.restlet.data.Protocol;
import org.restlet.routing.Router;

public class ApiWithFineGrainedAuthorization extends Application {

	@Override
	public org.restlet.Restlet createInboundRoot() {
		Router root = new Router(getContext());
		root.attach("/resource1", ResourceFineGrained.class);
		return root;
	}
	
	public static void main(String[] args) throws Exception {
		//Attach application to http://localhost:9000/v1
        Component c = new Component();
        c.getServers().add(Protocol.HTTP, 9000);
        c.getDefaultHost().attach("/v1", new ApiWithMethodAuthorization());
        c.start();
	}
}
