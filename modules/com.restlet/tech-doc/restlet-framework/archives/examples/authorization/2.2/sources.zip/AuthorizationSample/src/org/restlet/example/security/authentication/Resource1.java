package org.restlet.example.security.authentication;

import org.restlet.resource.Delete;
import org.restlet.resource.Get;
import org.restlet.resource.Patch;
import org.restlet.resource.Post;
import org.restlet.resource.Put;
import org.restlet.resource.ServerResource;

public class Resource1 extends ServerResource {

	@Get
	public String represent() throws Exception {
		return this.getClass().getSimpleName() + " found !";
	}
	
	@Post
	public String add() {
		return this.getClass().getSimpleName() + " posted !";
	}
	
	@Put
	public String change() {
		return this.getClass().getSimpleName() + " changed !";
	}
	
	@Patch
	public String partiallyChange() {
		return this.getClass().getSimpleName() + " partially changed !";
	}
	
	@Delete
	public String destroy() {
		return this.getClass().getSimpleName() + " deleted!";
	}
}
