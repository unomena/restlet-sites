package org.restlet.example.security.authentication;

import org.restlet.Application;
import org.restlet.Component;
import org.restlet.Restlet;
import org.restlet.data.ChallengeScheme;
import org.restlet.data.Method;
import org.restlet.data.Protocol;
import org.restlet.routing.Router;
import org.restlet.security.ChallengeAuthenticator;
import org.restlet.security.MemoryRealm;
import org.restlet.security.MethodAuthorizer;
import org.restlet.security.Role;
import org.restlet.security.User;

public class ApiWithMethodAuthorization extends Application {

    //Define role names
    public static final String ROLE_USER = "user";
    public static final String ROLE_OWNER = "owner";
    
    @Override
    public Restlet createInboundRoot() {
        //ChallengeAuthenticator
        ChallengeAuthenticator ca = createAuthenticator();
        ca.setOptional(true);
        
        //MethodAuthorizer
        MethodAuthorizer ma = createMethodAuthorizer();
        ca.setNext(ma);
        
        //Router
        ma.setNext(createRouter());
        return ca;
    }
    
    private ChallengeAuthenticator createAuthenticator() {
        ChallengeAuthenticator guard = new ChallengeAuthenticator(
                getContext(), ChallengeScheme.HTTP_BASIC, "realm");

        //Create in-memory users with roles
        MemoryRealm realm = new MemoryRealm();
        User user = new User("user", "user");
        realm.getUsers().add(user);
        realm.map(user, Role.get(this, ROLE_USER));
        User owner = new User("owner", "owner");
        realm.getUsers().add(owner);
        realm.map(owner, Role.get(this, ROLE_OWNER));
        

        //Attach verifier to check authentication and enroler to determine roles
        guard.setVerifier(realm.getVerifier());
        guard.setEnroler(realm.getEnroler());
        return guard;
    }
    
    private MethodAuthorizer createMethodAuthorizer() {
    	//Authorize GET for anonymous users and GET, POST, PUT, DELETE for 
    	//authenticated users
    	MethodAuthorizer methodAuth = new MethodAuthorizer();
    	methodAuth.getAnonymousMethods().add(Method.GET);
    	methodAuth.getAuthenticatedMethods().add(Method.GET);
    	methodAuth.getAuthenticatedMethods().add(Method.POST);
    	methodAuth.getAuthenticatedMethods().add(Method.PUT);
    	methodAuth.getAuthenticatedMethods().add(Method.DELETE);
    	return methodAuth;
    }

    private Router createRouter() {
        //Attach Server Resources to given URL
        Router router = new Router(getContext());
        router.attach("/resource1/", Resource1.class);
        router.attach("/resource2/", Resource2.class);
        return router;
    }
    
    public static void main(String[] args) throws Exception {
        //Attach application to http://localhost:9000/v1
        Component c = new Component();
        c.getServers().add(Protocol.HTTP, 9000);
        c.getDefaultHost().attach("/v1", new ApiWithMethodAuthorization());
        c.start();
    }
}