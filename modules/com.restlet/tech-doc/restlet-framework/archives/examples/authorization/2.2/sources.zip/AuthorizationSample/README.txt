This project contains four runnable classes: 

ApiWithFineGrainedAuthorization -> shows fine grained authorization
ApiWithMethodAuthorization -> shows coarse grained authorization by methods
ApiWithRoleAuthorization -> shows coarse grained authorization by roles
ApiWithComplexAuthorizationPolicy -> shows mixed coarse grained authorization

You must add a binary in your build path to launch them.
Download the last stable version of restlet JSE edition (http://restlet.org/download/current#release=stable&edition=jse) and add the binary org.restlet.jar