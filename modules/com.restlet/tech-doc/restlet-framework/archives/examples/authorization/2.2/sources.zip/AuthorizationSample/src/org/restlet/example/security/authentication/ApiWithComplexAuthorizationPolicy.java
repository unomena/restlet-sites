package org.restlet.example.security.authentication;

import java.util.ArrayList;
import java.util.List;

import org.restlet.Application;
import org.restlet.Component;
import org.restlet.Restlet;
import org.restlet.data.ChallengeScheme;
import org.restlet.data.Method;
import org.restlet.data.Protocol;
import org.restlet.routing.Router;
import org.restlet.security.ChallengeAuthenticator;
import org.restlet.security.MemoryRealm;
import org.restlet.security.MethodAuthorizer;
import org.restlet.security.Role;
import org.restlet.security.RoleAuthorizer;
import org.restlet.security.User;

public class ApiWithComplexAuthorizationPolicy extends Application {

    //Define role names
    public static final String ROLE_USER = "user";
    public static final String ROLE_OWNER = "owner";

    @Override
    public Restlet createInboundRoot() {
        Router root = new Router(getContext());
        root.setDefaultMatchingMode(Router.MODE_BEST_MATCH);
        
        //Admin authenticator
        ChallengeAuthenticator caAdmin = createAuthenticator();
        root.attach("/admin", caAdmin);
        
        //Role authorizer
        RoleAuthorizer ra = createRoleAuthorizer();
        caAdmin.setNext(ra);
        
        //Router 2
        Router router2 = new Router(getContext());
        ra.setNext(router2);
        router2.attach("/resource1", Resource1.class);
        router2.attach("/resource2", Resource2.class);
        
        //Resource 1 authenticator
        ChallengeAuthenticator caR1 = createAuthenticator();
        root.attach("/resource1", caR1);
        caR1.setOptional(true);
        
        //Resource 1 method authorizer
        List<Method> authenticatedR1 = new ArrayList<>();
        authenticatedR1.add(Method.GET);
        authenticatedR1.add(Method.POST);
        MethodAuthorizer maR1 = createMethodAuthorizer(new ArrayList<Method>(), authenticatedR1);
        caR1.setNext(maR1);
        maR1.setNext(Resource1.class);
        
        //Resource 2 authenticator
        ChallengeAuthenticator caR2 = createAuthenticator();
        caR2.setOptional(true);
        root.attach("/resource2", caR2);
        
        //Resource 2 method authorizer
        List<Method> anonymousR2 = new ArrayList<>();
        anonymousR2.add(Method.GET);
        List<Method> authenticatedR2 = new ArrayList<>();
        authenticatedR2.add(Method.GET);
        authenticatedR2.add(Method.POST);
        authenticatedR2.add(Method.PUT);
        authenticatedR2.add(Method.PATCH);
        authenticatedR2.add(Method.OPTIONS);
        MethodAuthorizer maR2 = createMethodAuthorizer(anonymousR2, authenticatedR2);
        caR2.setNext(maR2);
        maR2.setNext(Resource2.class);
        
        return root;
    }
    
    private ChallengeAuthenticator createAuthenticator() {
        ChallengeAuthenticator guard = new ChallengeAuthenticator(
                getContext(), ChallengeScheme.HTTP_BASIC, "realm");

        //Create in-memory users with roles
        MemoryRealm realm = new MemoryRealm();
        User user = new User("user", "user");
        realm.getUsers().add(user);
        realm.map(user, Role.get(this, ROLE_USER));
        User owner = new User("owner", "owner");
        realm.getUsers().add(owner);
        realm.map(owner, Role.get(this, ROLE_OWNER));
        

        //Attach verifier to check authentication and enroler to determine roles
        guard.setVerifier(realm.getVerifier());
        guard.setEnroler(realm.getEnroler());
        return guard;
    }
    
    private MethodAuthorizer createMethodAuthorizer(List<Method> anonymous, List<Method> authenticated) {
    	MethodAuthorizer methodAuth = new MethodAuthorizer();
    	methodAuth.setAnonymousMethods(anonymous);
    	methodAuth.setAuthenticatedMethods(authenticated);
    	return methodAuth;
    }
    
    private RoleAuthorizer createRoleAuthorizer() {
    	//Authorize owners and forbid users on roleAuth's children
    	RoleAuthorizer roleAuth = new RoleAuthorizer();
    	roleAuth.getAuthorizedRoles().add(Role.get(this, ROLE_OWNER));
    	roleAuth.getForbiddenRoles().add(Role.get(this, ROLE_USER));
    	return roleAuth;
    }
    
    public static void main(String[] args) throws Exception {
        //Attach application to http://localhost:9000/v1
        Component c = new Component();
        c.getServers().add(Protocol.HTTP, 9000);
        c.getDefaultHost().attach("/v1", new ApiWithComplexAuthorizationPolicy());
        c.start();
    }
}