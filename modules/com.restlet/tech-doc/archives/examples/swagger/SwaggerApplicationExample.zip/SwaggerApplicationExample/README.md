# Code sample for Swagger extension

## Configuration

- Copy-paste folder src in your project
- Download version 2.3-SNAPSHOT of Restlet Framework [here](http://restlet.com/download/current#release=unstable&edition=jse&distribution=zip)
- add following jars to your classpath (found in folder libraries of Restlet Framework)
  - org.restlet.jar
  - org.restlet.ext.jackson.jar
  - org.restlet.ext.apispark.jar
  - org.restlet.ext.swagger.jar
  - all jars in folder com.fasterxml.jackson_2.2

## Retrieve the Swagger documentation

- Run class: WebApiHost, contained in package org.restlet.tutorial
- Fetch page: http://localhost:9000/v1/api-docs