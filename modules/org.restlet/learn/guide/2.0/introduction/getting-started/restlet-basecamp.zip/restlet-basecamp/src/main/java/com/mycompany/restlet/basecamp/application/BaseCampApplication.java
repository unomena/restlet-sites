package com.mycompany.restlet.basecamp.application;

import org.restlet.Application;

public class BaseCampApplication extends Application {
}