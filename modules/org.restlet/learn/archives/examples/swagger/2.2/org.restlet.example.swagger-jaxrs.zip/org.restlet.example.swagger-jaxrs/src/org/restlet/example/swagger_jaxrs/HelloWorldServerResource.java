package org.restlet.example.swagger_jaxrs;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;

@Path("/hello")
@Api(value = "/hello", description = "This is a sample \"Hello, world\" resource")
public class HelloWorldServerResource {

    @GET
    @Produces("text/plain")
    @ApiOperation(value = "hello", notes = "Returns the representation of hello resource.")
    public String hello() {
        return "hello, world";
    }
}
