package org.restlet.example.swagger_jaxrs;

import javax.ws.rs.core.Application;

import org.restlet.Component;
import org.restlet.data.Protocol;
import org.restlet.ext.jaxrs.JaxRsApplication;
import org.restlet.ext.swagger.SwaggerUiRestlet;

public class SampleServer {
    public static void main(String[] args) throws Exception {
        // create the application container
        Component comp = new Component();
        comp.getServers().add(Protocol.HTTP, 8182);

        // create JAX-RS runtime environment
        JaxRsApplication application = new JaxRsApplication();
        // attach ApplicationConfig
        Application app = new SampleJaxrApplication();
        application.add(app);

        // attach the application to the component and start it
        comp.getDefaultHost().attach("/v1", application);

        // then, add the Swagger documentation endpoint
        String basePath = "http://example.com:8182";
        String docPath = "/api-doc";

        SwaggerUiRestlet apiDoc = new SwaggerUiRestlet();
        // specify the documented application
        apiDoc.setApiInboundRoot(application);
        // add extra documentation
        apiDoc.setApiVersion("1.0.0");
        apiDoc.setAuthor("Restlet Inc.");
        apiDoc.setBasePath(basePath + "/v1");
        apiDoc.setJsonPath(basePath + docPath);
        // attach the Swagger documentation endpoint
        comp.getDefaultHost().attach(docPath, apiDoc);

        comp.start();
    }
}
