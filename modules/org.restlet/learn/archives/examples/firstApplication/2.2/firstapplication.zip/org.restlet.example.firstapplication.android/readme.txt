Here are all the binaries you will need from the restlet Android edition:
Put them all in libs (build path is already set to search for them in this repository)

From restlet-android-versionNumber/lib

org.restlet.ext.jackson.jar
org.restlet.jar

On Eclipse: 
If you do not have Android Development Tools plugin installed on Eclipse, then go to
Help -> Eclipse Market Place type ADT and install Android Development Tools for Eclipse
You will need a version of android >= 4.0.3 (API 15+ required)

Then go to Window -> Android SDK Manager and install/update the latest version of android build tools