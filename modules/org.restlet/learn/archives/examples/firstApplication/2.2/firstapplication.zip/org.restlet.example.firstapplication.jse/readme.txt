Here are all the binaries you will need from the restlet JSE edition:
Put them all in lib (build path is already set to search for them in this repository)

From restlet-jse-versionNumber/lib/com.fasterxml.jackson_versionNumber

com.fasterxml.jackson.annotations.jar
com.fasterxml.jackson.core.jar
com.fasterxml.jackson.csv.jar
com.fasterxml.jackson.databind.jar
com.fasterxml.jackson.jaxb.jar
com.fasterxml.jackson.smile.jar
com.fasterxml.jackson.xml.jar
com.fasterxml.jackson.yaml.jar

From restlet-jse-versionNumber/lib

org.restlet.ext.jackson.jar
org.restlet.jar